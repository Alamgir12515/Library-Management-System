package com.mysql.jdbc.exceptions;

public class MySQLIntegrityConstraintViolationException {

}
